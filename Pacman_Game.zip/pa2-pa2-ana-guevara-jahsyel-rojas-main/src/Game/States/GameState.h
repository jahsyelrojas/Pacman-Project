#pragma once

#include "State.h"
#include "Player.h"
#include "MapBuilder.h"
#include "EntityManager.h"
#include "PauseState.h"


class GameState: public State{
    public: 
        GameState();
		~GameState();
		void reset();
		void tick();
		void render();
		void keyPressed(int key);
		void mousePressed(int x, int y, int button);
		void keyReleased(int key);
		int getFinalScore();
		Map* map;
		
	
	
	private:
		ofSoundPlayer music;
		ofImage mapImage;
		MapBuilder mapBuilder;
		
		int finalScore=0;
		
		

};