#pragma once

#include "State.h"
#include "Button.h"
#include "Animation.h"



class ChoosePlayerState : public State {
private:
    Button *pacButton;
    Button *chompButton;
    ofImage pacmanSprite;
    ofImage chompSprite;
    ofImage img1;
    Animation* anim;
    string getChooseCharacter();

public:
    ChoosePlayerState();
    ~ChoosePlayerState();
    void tick();
    void render();
    void keyPressed(int key);
    void mousePressed(int x, int y, int button);
    void reset();
    string chooseCharacter = "";
};