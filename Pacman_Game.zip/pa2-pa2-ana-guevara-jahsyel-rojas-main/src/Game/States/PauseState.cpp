#include "PauseState.h"
#include "Entity.h"


PauseState::PauseState(){
    music.stop();
    resumeButton = new Button(ofGetWindowWidth()/2-32, ofGetWindowHeight()/2-25, 64, 50, "Resume");
    quitButton = new Button(ofGetWindowWidth()/2-32, ofGetWindowHeight()/2+35, 64, 50, "Quit");
    
}

void PauseState::tick(){
    resumeButton->tick();
    quitButton->tick();
    if(resumeButton->wasPressed()){
        setNextState("Game");
        setFinished(true);
        quitReset = false;
        
    }
    if(quitButton->wasPressed()){
        setFinished(true);
        setNextState("over");
        quitReset = true;
    }
   
    
}

void PauseState::render(){
    ofDrawBitmapString("Paused", ofGetWidth()/2-10, ofGetHeight()/2-300, 50);
 
    ofSetBackgroundColor(0, 0, 0);
    ofSetColor(256, 256, 256);
    resumeButton->render();
    quitButton->render();
}

void PauseState::keyPressed(int key){
  
}

void PauseState::reset(){
    setFinished(false);
    setNextState("");
    resumeButton->reset();
    quitButton->reset();
    
}

void PauseState::mousePressed(int x, int y, int button){
    resumeButton->mousePressed(x, y);
    quitButton->mousePressed(x, y);
}

PauseState::~PauseState(){
    delete resumeButton;
    delete quitButton;
    
}


