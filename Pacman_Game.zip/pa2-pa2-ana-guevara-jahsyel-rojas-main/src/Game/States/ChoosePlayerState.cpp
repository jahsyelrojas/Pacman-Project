#include "ChoosePlayerState.h"

ChoosePlayerState:: ChoosePlayerState() {
    pacmanSprite.load("images/pacman.png");
    chompSprite.load("images/chomp.png");
    pacButton = new Button(ofGetWidth()/2 - 64, ofGetHeight()/2, 64, 40, "Pacman");
    chompButton = new Button(ofGetWidth()/2 + 64, ofGetHeight()/2, 64, 40, "Chomp-Chomp");
    
    img1.load("images/pacman.png");
    vector<ofImage> rightAnimframes;
    ofImage temp;
    for(int i=0; i<3; i++){
        temp.cropFrom(img1, i*16, 0, 16, 16);
        rightAnimframes.push_back(temp);
    }
	anim = new Animation(10,rightAnimframes);

}
void ChoosePlayerState::tick() { 
        pacButton->tick();
        chompButton->tick();
        anim->tick();

        if(pacButton->wasPressed()){
            setNextState("Game");
            chooseCharacter = "Pacman";
            setFinished(true);       
        }

        if(chompButton->wasPressed()){
            setNextState("Game");
            chooseCharacter = "Chomp-Chomp";
            setFinished(true);
        }   
}

void ChoosePlayerState::render() {
    ofDrawBitmapString("Chosen Character: " + chooseCharacter, ofGetWidth() / 2, ofGetHeight() / 2 - 100,100);
    ofSetBackgroundColor(255, 213, 128);
    ofSetColor(256, 256, 256);
    anim->getCurrentFrame().draw(ofGetWidth()/2, ofGetHeight()/2-100, 100, 100);
    pacButton->render();
    chompButton->render();

    
        
}

void ChoosePlayerState::keyPressed(int key) {
    
}

void ChoosePlayerState::mousePressed(int x, int y, int button){
        pacButton->mousePressed(x, y);
        chompButton->mousePressed(x, y);
        
    }

void ChoosePlayerState::reset(){
        pacButton->reset();
        chompButton->reset();

        chooseCharacter = "";
    }

    string chooseCharacter;

string ChoosePlayerState::getChooseCharacter(){
    return chooseCharacter;
}

ChoosePlayerState::~ChoosePlayerState(){
    delete pacButton;
    delete chompButton;
    delete anim;
}