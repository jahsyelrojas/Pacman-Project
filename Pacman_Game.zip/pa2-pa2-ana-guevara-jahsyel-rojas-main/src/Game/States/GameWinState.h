#pragma once

#include "State.h"
#include "Button.h"
#include "Animation.h" 

class GameWinState : public State {
private:
    ofImage img1;
    Button *playAgainButton;
    Button *quitButton;
    Animation* anim;
    int score = 0;

public:
    GameWinState();
    ~GameWinState();
    void tick();
    void render();
    void keyPressed(int key);
    void mousePressed(int x, int  y, int button);
    void reset();
    void setScore(int);
};