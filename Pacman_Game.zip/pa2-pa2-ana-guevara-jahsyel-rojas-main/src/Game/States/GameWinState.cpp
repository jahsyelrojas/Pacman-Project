#include "GameWinState.h"

GameWinState::GameWinState() {
	playAgainButton = new Button(ofGetWidth()/2, ofGetHeight()/2 + 100, 64, 50, "Play Again");
	quitButton = new Button(ofGetWidth()/2, ofGetHeight()/2 + 150, 64, 50, "Quit");
    img1.load("images/pacman.png");
	vector<ofImage> rightAnimframes;
    ofImage temp;
	for(int i=0; i<3; i++){
        temp.cropFrom(img1, i*16, 0, 16, 16);
        rightAnimframes.push_back(temp);
    }
	anim = new Animation(10,rightAnimframes);

}
void GameWinState::tick() {
	playAgainButton->tick();
    quitButton->tick();
	anim->tick();
	if(playAgainButton->wasPressed()){
		setNextState("Game");
		setFinished(true);

	}

    if(quitButton->wasPressed()){
        setFinished(true);
        ofExit();
    }
}
void GameWinState::render() {
	ofDrawBitmapString("Score: " + to_string(score), ofGetWidth()/2, ofGetHeight()/2-300, 50);
	ofDrawBitmapString("!!!!YOU WIN!!!!!", ofGetWidth()/2, ofGetHeight()/2 + 20, 50);
	ofSetBackgroundColor(0, 0, 0);
	ofSetColor(256, 256, 256);
	anim->getCurrentFrame().draw(ofGetWidth()/2, ofGetHeight()/2-100, 100, 100);
	playAgainButton->render();
    quitButton->render();


}

void GameWinState::keyPressed(int key){
	
}

void GameWinState::mousePressed(int x, int y, int button){
	playAgainButton->mousePressed(x, y);
    quitButton->mousePressed(x, y);
}

void GameWinState::reset(){
	setFinished(false);
	setNextState("");
	playAgainButton->reset();
    quitButton->reset();
}

void GameWinState::setScore(int sc){
    score = sc;
}

GameWinState::~GameWinState(){
	delete playAgainButton;
    delete quitButton;
	delete anim;
}