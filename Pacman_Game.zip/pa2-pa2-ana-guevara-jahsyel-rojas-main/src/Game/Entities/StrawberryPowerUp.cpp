#include "StrawberryPowerUp.h"

StrawberryPowerup::StrawberryPowerup(Player* p) {
    this->p = p;
}

void StrawberryPowerup::activate() {
   p->renderPac = false;
   p->isInvincible = false;
   p->invisibilityCounter = 30*6;
}
string StrawberryPowerup::getName() {
    return "Invisibility/ \n"
            "Invulnerability";
}