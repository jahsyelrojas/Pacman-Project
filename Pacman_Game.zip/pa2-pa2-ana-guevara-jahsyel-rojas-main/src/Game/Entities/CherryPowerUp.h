#pragma once
#include "PowerUp.h"
#include "Player.h"
#include "EntityManager.h"

class CherryPowerUp : public Powerup{
    public:

        void activate();
        CherryPowerUp(Player* p);
        Player* p;
        string getName();
    

};