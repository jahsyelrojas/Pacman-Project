#include "CherryPowerUp.h"
#include "Entity.h"

CherryPowerUp::CherryPowerUp(Player* p) {
   this->p = p;
   
}

void CherryPowerUp::activate() {
   
    Entity* teleport = em->entities[ofRandom(em->entities.size())];
    p->setPosX(teleport->getPosX());
    p->setPosY(teleport->getPosY());
   
}

string CherryPowerUp::getName() {
    return "Teleportation";
}