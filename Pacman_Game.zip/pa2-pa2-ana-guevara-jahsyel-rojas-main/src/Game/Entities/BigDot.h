#pragma once

#include "Entity.h"

class BigDot: public Entity{
    public:
        BigDot(int, int, int, int, ofImage);
        
};