#pragma once
#include "Player.h"
#include "Powerup.h"

class StrawberryPowerup: public Powerup{
    public:
        StrawberryPowerup(Player* p);
        void activate();
        Player* p;
        string getName();
};