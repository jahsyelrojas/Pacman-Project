#include "ApplePowerUp.h"

ApplePowerUp::ApplePowerUp(Player* p){
    this->p = p;
}

void ApplePowerUp::activate(){
    p->renderPac = true;
    p->isFaster = true;
    p->speedCounter = 30*6;
    p->speedDoubled = 2 * p->speed;
}

string ApplePowerUp::getName() {
    return "Apple-Speed";
}