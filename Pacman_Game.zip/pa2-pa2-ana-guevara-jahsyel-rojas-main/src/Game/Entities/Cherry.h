#pragma once
#include "Entity.h"

class Cherry : public Entity{

    public:
        Cherry(int, int, int, int, ofImage);
};