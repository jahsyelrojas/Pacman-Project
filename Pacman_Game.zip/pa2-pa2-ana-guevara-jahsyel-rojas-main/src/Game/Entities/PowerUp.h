#pragma once
#include "Entity.h"
#include "EntityManager.h"

class Powerup {
    public:

        EntityManager* em;
        Entity* p =0;
        virtual void activate() = 0;
        virtual string getName() = 0;
};