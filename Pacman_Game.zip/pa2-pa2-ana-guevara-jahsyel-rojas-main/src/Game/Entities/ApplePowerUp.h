#pragma once
#include "Player.h"
#include "PowerUp.h"

class ApplePowerUp: public Powerup{
    public:
    ApplePowerUp(Player* p);
    void activate();
    Player* p;
    string getName();
};