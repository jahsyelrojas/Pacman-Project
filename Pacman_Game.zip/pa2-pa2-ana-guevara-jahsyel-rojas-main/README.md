# PA2: Pacman
This repository is part of a Programming Assignment for the Advanced Programming Course.

## Setup
1. Clone this project inside an OpenFrameworks installation's "apps/myApps/" directory
2. Build & Run the project

## Submitting Assignment
To submit this assignment, create a Release with the branch that holds all the changes you have added. If no Release is made, the last commit to the master branch will be graded.
Don't forget that you must also fill out an evaluation form in Moodle to consider the project submitted.

## Grading

(802-21-8475) (Jahsyel Rojas) (jahsyel.rojas@upr.edu)
(802-22-7689) (Ana Guevara) (ana.guevara@upr.edu)

Any project that doesn't compile will receive a 0.

If a partner has no commits in the repositories, they'll will receive a 0.

## Student Notes
If you have any bonus specs, bonus or any details the TA's should know, you should include it here:
